import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ShoppingCart, Trash2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

const machines = [
  {
    id: 1,
    name: "LineMaster 3000",
    description: "High-efficiency road marking machine with GPS alignment.",
    price: 4999,
    image: "/images/linemaster3000.jpg"
  },
  {
    id: 2,
    name: "StripePro X",
    description: "Durable and fast, perfect for highways and urban areas.",
    price: 6999,
    image: "/images/stripeprox.jpg"
  },
  {
    id: 3,
    name: "PaintJet Mini",
    description: "Compact machine ideal for small projects and tight spaces.",
    price: 2999,
    image: "/images/paintjetmini.jpg"
  }
];

export default function RoadMarkingShop() {
  const [cart, setCart] = useState([]);
  const [search, setSearch] = useState("");
  const [checkoutOpen, setCheckoutOpen] = useState(false);

  const addToCart = (machine) => {
    const existing = cart.find((item) => item.id === machine.id);
    if (existing) {
      setCart(
        cart.map((item) =>
          item.id === machine.id ? { ...item, quantity: item.quantity + 1 } : item
        )
      );
    } else {
      setCart([...cart, { ...machine, quantity: 1 }]);
    }
  };

  const removeFromCart = (id) => {
    setCart(cart.filter((item) => item.id !== id));
  };

  const updateQuantity = (id, amount) => {
    setCart(
      cart.map((item) =>
        item.id === id ? { ...item, quantity: Math.max(1, item.quantity + amount) } : item
      )
    );
  };

  const total = cart.reduce((acc, item) => acc + item.price * item.quantity, 0);

  const filteredMachines = machines.filter((m) =>
    m.name.toLowerCase().includes(search.toLowerCase())
  );

  const handleCheckout = async () => {
    // Call the API to create Stripe checkout session
    const response = await fetch("/api/checkout", {
      method: "POST",
      body: JSON.stringify({ cart }),
      headers: { "Content-Type": "application/json" }
    });

    const data = await response.json();
    window.location.href = data.url;
  };

  return (
    <div className="p-10">
      <h1 className="text-3xl font-bold mb-4">Road Marking Machines</h1>
      <Input
        placeholder="Search machines..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="mb-5 w-full"
      />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredMachines.map((machine) => (
          <Card key={machine.id}>
            <img src={machine.image} alt={machine.name} className="w-full h-48 object-cover rounded-t-2xl" />
            <CardContent className="p-4">
              <h2 className="text-xl font-semibold mb-2">{machine.name}</h2>
              <p className="text-gray-600 mb-2">{machine.description}</p>
              <p className="text-lg font-bold mb-4">${machine.price}</p>
              <Button onClick={() => addToCart(machine)} className="w-full flex items-center justify-center gap-2">
                <ShoppingCart className="w-4 h-4" /> Add to Cart
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="mt-10">
        <h2 className="text-2xl font-bold mb-4">Cart Summary</h2>
        {cart.length === 0 ? (
          <p>Your cart is empty.</p>
        ) : (
          <div className="space-y-2">
            {cart.map((item) => (
              <div key={item.id} className="flex items-center justify-between border p-3 rounded">
                <div>
                  <p className="font-semibold">{item.name}</p>
                  <p>${item.price} × {item.quantity}</p>
                </div>
                <div className="flex items-center gap-2">
                  <Button size="sm" onClick={() => updateQuantity(item.id, -1)}>-</Button>
                  <span>{item.quantity}</span>
                  <Button size="sm" onClick={() => updateQuantity(item.id, 1)}>+</Button>
                  <Button size="sm" variant="destructive" onClick={() => removeFromCart(item.id)}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))}
            <p className="text-xl font-bold mt-4">Total: ${total}</p>
            <Button className="mt-4 w-full" onClick={handleCheckout}>Proceed to Checkout</Button>
          </div>
        )}
      </div>
    </div>
  );
}
